public abstract class Pessoa {
    protected String nome;
    protected String endereco;
    protected double rendimentos;

    public Pessoa(String nome, String endereco, double rendimentos){
        this.nome = nome;
        this.endereco = endereco;
        this.rendimentos = rendimentos;
    }


}
